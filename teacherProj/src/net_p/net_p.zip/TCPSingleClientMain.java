package net_p;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPSingleClientMain {

	public static void main(String[] args) throws Exception {
		
			Socket socket = new Socket("192.168.219.113",8888);
			System.out.println("클라이언트 서버 접속 성공");
			
			new TCPSingleSender(socket).start();
			new TCPSingleReceiver(socket).start();
			
			
	}

}
//서버는 gui로 만들필요가없다 클라이언트 지금 보이는창만 gui로