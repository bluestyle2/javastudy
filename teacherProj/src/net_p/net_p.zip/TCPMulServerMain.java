package net_p;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JFrame;

public class TCPMulServerMain {

	ArrayList<DataOutputStream> arr = new ArrayList<DataOutputStream>();

	public TCPMulServerMain() throws Exception {
		Collections.synchronizedList(arr);

		ServerSocket server = new ServerSocket(8888);
		new Frame();
		while (true) {

			new TCPMulReceiver(server.accept()).start();
			

		}
	}

	class TCPMulReceiver extends Thread {

		String name;
		DataOutputStream dos;
		DataInputStream dis;

		public TCPMulReceiver(Socket socket) throws Exception {
			name = "[" + socket.getInetAddress() + "]";
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
		}

		@Override
		public void run() {

			try {

				sendToAll(name + " 님이 채팅방에 입장하셨습니다");
				arr.add(dos);
				sendToAll("접속자 수:" + arr.size());

				while (dis != null) {
					sendToAll(dis.readUTF());
				}

			} catch (IOException e) {

				e.printStackTrace();
			} finally {

				arr.remove(dos);
				sendToAll(name + " 님이 채팅방을 나가셨습니다.");
				sendToAll("접속자 수:" + arr.size());
			}

		}

	}

	class Frame extends JFrame{
		
		Frame() {
			setBounds(100,100,600,500);
			setLayout(null);
			setVisible(true);
			
			
		}
	}
	
	void sendToAll(String msg) {
		for (DataOutputStream dd : arr) {
			try {
				dd.writeUTF(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws Exception {

		new TCPMulServerMain();
		
	}

}