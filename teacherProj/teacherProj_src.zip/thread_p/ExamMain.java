package thread_p;

public class ExamMain {

	public static void main(String[] args) {
		

	}

}
