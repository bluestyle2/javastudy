package basic_p;

public class SecMain {

	public static void main(String[] args) {
		
		System.out.println("엄마상어");
	}
}
