package basic_p;

public class ThirdMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("아빠상어"+123);
	}

}
