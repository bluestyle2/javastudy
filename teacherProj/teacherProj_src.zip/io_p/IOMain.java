package io_p;

public class IOMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}


