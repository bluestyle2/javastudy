package collection_p;

public class LottoMain {

	public static void main(String[] args) {
		
		

	}

}
