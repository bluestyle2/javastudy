package pac_1.sub;

public class GGG {
	
	public String a = "pac_1.sub.GGG.public a";
	String b = "pac_1.sub.GGG.b";
	private String c = "pac_1.sub.GGG.c";
	
	public void meth_1() {
		
		System.out.println("pac_1.sub.GGG.public meth_1() 실행");
	}
	
	void meth_2( ) {
		
		System.out.println("pac_1.sub.GGG.meth_2() 실행");
	}
	private void meth_3() {
		
		System.out.println("pac_1.sub.GGG.private meth_3() 실행");
	}
}