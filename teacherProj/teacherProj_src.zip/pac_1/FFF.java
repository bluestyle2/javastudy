package pac_1;

public class FFF {
	
	public String a = "pac_1.FFF.public a";
	String b = "pac_1.FFF.b";
	private String c = "pac_1.FFF.c";
	
	public void meth_1() {
		
		System.out.println("pac_1.FFF.public meth_1() 실행");
	}
	
	void meth_2( ) {
		
		System.out.println("pac_1.FFF.meth_2() 실행");
	}
	private void meth_3() {
		
		System.out.println("pac_1.FFF.private meth_3() 실행");
	}
}