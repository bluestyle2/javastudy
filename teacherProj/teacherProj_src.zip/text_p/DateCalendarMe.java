package text_p;

import java.sql.Date;

public class DateCalendarMe {

	public static void main(String[] args) {
		
		
		
		Date day1 = new Date(2021-1900,9-1,1);
		System.out.println(day1);
		int a=0;
		for (int i = 0; i < 31; i++) {
	//		if()
			day1.setDate(i);
			
			System.out.println(day1);
			
		}
		
	}

}
