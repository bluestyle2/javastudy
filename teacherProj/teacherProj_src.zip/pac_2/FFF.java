package pac_2;

public class FFF {
	
	public String a = "pac_2.FFF.public a";
	String b = "pac_2.FFF.b";
	private String c = "pac_2.FFF.c";
	
	public void meth_1() {
		
		System.out.println("pac_2.FFF.public meth_1() 실행");
	}
	
	void meth_2( ) {
		
		System.out.println("pac_2.FFF.meth_2() 실행");
	}
	private void meth_3() {
		
		System.out.println("pac_2.FFF.private meth_3() 실행");
	}
}