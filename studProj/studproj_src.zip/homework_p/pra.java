package homework_p;

import javax.swing.JFrame;

public class pra extends JFrame{
	pra(){
		setBounds(100,10,1200,800);
		
		setVisible(true);
	}
	public static void main(String[] args) {
		pra a = new pra();

	}

}
