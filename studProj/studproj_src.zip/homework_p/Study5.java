package homework_p;

public class Study5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

//회원가입 프로그램을 작성하세요
//입력사항 - id, pw, pw확인, 성명, 이메일, 취미, 특기, 전화번호, 핸드폰, 생년월일, 성별
//필수 입력사항 - id, pw, pw확인, 성명, 전화번호, 생년월일, 성별 (값이 없으면 에러 발생)
//유효성 검사 - 생년 : 1980 이전 출생자만 가입 가능
//          비밀번호, 비밀번호 확인은 값이 같아야만 가능