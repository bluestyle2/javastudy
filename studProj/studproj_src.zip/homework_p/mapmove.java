package homework_p;

import javax.swing.JFrame;

public class mapmove extends JFrame {

	mapmove() {
		setBounds(100,200,500,500);
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		

	}

}
