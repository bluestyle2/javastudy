package davinciProj;

public class PlayerInfoDTO {   
   
   String id, pw, birth;
   int jelly=0, dino=0, hp=0;
   
   public PlayerInfoDTO() {
      
   }
   
      
   public PlayerInfoDTO(String id, String pw) {
	super();
	this.id = id;
	this.pw = pw;
}


public PlayerInfoDTO(String id, String pw, String birth, int jelly, int dino, int hp) {
      this.id = id;
      this.pw = pw;
      this.birth = birth;
      this.jelly = jelly;
      this.dino = dino;
      this.hp = hp;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getPw() {
      return pw;
   }

   public void setPw(String pw) {
      this.pw = pw;
   }

   public String getBirth() {
      return birth;
   }

   public void setBirth(String birth) {
      this.birth = birth;
   }

   public int getJelly() {
      return jelly;
   }

   public void setJelly(int jelly) {
      this.jelly = jelly;
   }

   public int getDino() {
      return dino;
   }

   public void setDino(int dino) {
      this.dino = dino;
   }

   public int getHp() {
      return hp;
   }

   public void setHp(int hp) {
      this.hp = hp;
   }

   public String toString() {
      return id + ", " + pw + ", " + birth + ", " + jelly + ", " + dino
            + ", " + hp;
      
   }
      
}