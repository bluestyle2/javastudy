package davinciProj;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class LoginFrame extends JFrame {
	
	JPanel contentPane;
	JTextField tfUsername, tfPassword;
	JButton loginBtn, joinBtn;
	ImageIcon loginimg = new ImageIcon("davinci_img/mapintro.jpg");
	JLabel logintitle = new JLabel(loginimg);
	/*
	 * Create the frame.
	 */
	public LoginFrame() {
		
		setSize(1000, 800);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
				
		
		JLabel lblLogin = new JLabel("ID :");
		lblLogin.setBounds(350, 380, 69, 35);
		contentPane.add(lblLogin);
		
		JLabel lblPassword = new JLabel("PW :");
		lblPassword.setBounds(350, 420, 69, 35);
		contentPane.add(lblPassword);
		
		tfUsername = new JTextField();
		tfUsername.setBounds(410, 380, 176, 35);
		contentPane.add(tfUsername);
		//tfUsername.setColumns(10); //최대 입력글자수 10으로 설정
		
		tfPassword = new JTextField();
		tfPassword.setColumns(10);
		tfPassword.setBounds(410, 420, 176, 35);
		contentPane.add(tfPassword);
		
		joinBtn = new JButton("회원가입");
		joinBtn.setBounds(485, 480, 100, 40);
		contentPane.add(joinBtn);
		
		loginBtn = new JButton("로그인");
		loginBtn.setBounds(380, 480, 100, 40);
		contentPane.add(loginBtn);
		
		add(logintitle);
		logintitle.setBounds(0,0,1000,800);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//회원가입 액션
		joinBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//회원가입 frame = new 회원가입 frame();
			}
		});
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


}


