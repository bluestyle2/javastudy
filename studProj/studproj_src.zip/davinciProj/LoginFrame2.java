package davinciProj;

import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*
 * 로그인 클래스 
1. 사용자 ID, PW 입력받기

2.메소드: 유효성 검사
     2-1. 데이터: ID, PW를 가지고 유효성 검사
            - ID:    알파벳 + 숫자 or 알파벳   
            - pw   알파벳 + 숫자  
    2-2. id,pw 확인 멘트 기능
    2-3. 첫 로그인인지 확인하는 기능
3.유효성 검사 일치
     3-1 로그인 성공: 로비로 화면 이동           ○ NEW LOBBY(ID);

4. 유효성 검사 불일치
     4-1 로그인 실패: ID, PW 빈칸으로 변경

5. 회원가입 버튼 클릭
 * 
 * */

public class LoginFrame2 extends JFrame implements ActionListener {

	JPanel loginframe;
	JTextField tfUsername, tfPassword;
	JButton loginBtn, joinBtn;
	ImageIcon loginimg = new ImageIcon("davinci_img/loginscreen.png");
	JLabel logintitle = new JLabel(loginimg);
	boolean loginchk = false;

	/*
	 * Create the frame.
	 */
	public LoginFrame2() {

		setBounds(100, 100, 1000, 800);
		setLayout(null);
		setResizable(false);
		JLabel lblLogin = new JLabel("ID :");
		lblLogin.setBounds(350, 480, 69, 35);
		lblLogin.setForeground(Color.white);
		add(lblLogin);

		JLabel lblPassword = new JLabel("PW :");
		lblPassword.setBounds(350, 520, 69, 35);
		lblPassword.setForeground(Color.white);
		add(lblPassword);

		tfUsername = new JTextField();
		tfUsername.setBounds(410, 480, 176, 35);
		add(tfUsername);
		// tfUsername.setColumns(10); //최대 입력글자수 10으로 설정

		tfPassword = new JTextField();
		tfPassword.setColumns(10);
		tfPassword.setBounds(410, 520, 176, 35);
		add(tfPassword);

		joinBtn = new JButton("회원가입");
		joinBtn.setBounds(485, 580, 100, 40);
		// joinBtn.setBackground(new Color(171, 242, 0));
		joinBtn.setBackground(new Color(18, 102, 255));
		joinBtn.setForeground(Color.white);
		add(joinBtn);

		loginBtn = new JButton("로그인");
		loginBtn.setBounds(380, 580, 100, 40);
		loginBtn.setBackground(new Color(18, 102, 255));
		loginBtn.setForeground(Color.white);
		add(loginBtn);

		add(logintitle);
		logintitle.setBounds(0, 0, 1000, 800);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		loginBtn.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				PlayerInfoDAO dao = new PlayerInfoDAO();
				String user_id = tfUsername.getText();
				String user_pw = tfPassword.getText();
				PlayerInfoDTO dto = dao.detail(user_id, user_pw);
				if (dto != null) {
					JOptionPane.showMessageDialog(null, "로그인 성공하셨습니다.");
					loginchk = true;
					new FirstlogGacha();
				} else {
					JOptionPane.showMessageDialog(null, "로그인 실패하셨습니다.");
					tfUsername.setText(null);
					tfPassword.setText(null);
				}

			}
		});

	}

	class FirstlogGacha extends JFrame implements ActionListener {
		JButton rdchBtn;
		ImageIcon loginimg = new ImageIcon("davinci_img/loginscreen.png");
		
		public FirstlogGacha() {

			Random r = new Random();
			int rdch = r.nextInt(3)+1;
			
			setBounds(300, 300, 700, 500);
			setLayout(null);
			setResizable(false);

			rdchBtn = new JButton();
			rdchBtn.setBounds(250, 150, 200, 200);
			rdchBtn.setBackground(Color.white);
			add(rdchBtn);
			rdchBtn.setOpaque(false);
			
			JLabel rdchtxt = new JLabel("이 알에서 뭐가 나올까?");
			rdchtxt.setBounds(285, 380, 140, 35);
			rdchtxt.setForeground(Color.blue);
			add(rdchtxt);
			
			JLabel rdchres = new JLabel();
			rdchres.setBounds(285, 420, 160, 35);
			rdchres.setForeground(Color.black);
			add(rdchres);
			
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			rdchBtn.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					switch(rdch) {
					case 1: System.out.println("1번캐릭터를 뽑으셨습니다");
							rdchres.setText("티라노를 뽑으셨습니다");
							break;
					case 2: System.out.println("2번캐릭터를 뽑으셨습니다.");
							rdchres.setText("스테고를 뽑으셨습니다");
							break;
					case 3: System.out.println("3번캐릭터를 뽑으셨습니다.");
							rdchres.setText("잠을 자고싶습니다..");
							break;
					}
				}
			});
		}

		@Override
		public void actionPerformed(ActionEvent e) {}
	}

	/*
	 * //로그인 액션 loginBtn.addActionListener(new ActionListener() {
	 * 
	 * @Override public void actionPerformed(ActionEvent e) { getPw = new
	 * String(tfPassword.getText()); if (e.getSource() == loginBtn) { int sw = 0;
	 * PlayerInfoDAO dao = new PlayerInfoDAO(); ArrayList<PlayerInfoDTO> ar =
	 * dao.detail(this); if (tfUsername.getText().equals("") || getPw.equals("")) {
	 * JOptionPane.showMessageDialog(lblPassword, e); } else { for (int i = 0; i <
	 * ar.size(); i++) { if (ar.get(i).getId().equals(tfUsername.getText()) &&
	 * ar.get(i).getPw().equals(getPw)) {
	 * 
	 * //new LobbyClient(ar.get(i)).service(); sw = 1; dispose();
	 * 
	 * System.out.println("로그인성공"); break; } } if (sw == 0) {
	 * JOptionPane.showMessageDialog(lblPassword, e); tfUsername.setText("");
	 * tfPassword.setText(""); } } }
	 * 
	 * } });
	 * 
	 */

	// 회원가입 액션
	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {

		LoginFrame2 frame = new LoginFrame2();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
