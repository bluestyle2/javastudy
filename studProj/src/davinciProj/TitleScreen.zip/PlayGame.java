package davinciProj;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class PlayGame extends JFrame implements KeyListener {
	
	Random rd = new Random();
	JLabel character, character2;
	JLabel background, background2;
	JPanel p1;
	String id;
	ImageIcon img1 = new ImageIcon("gameimg/char1walk1.png");     //달리기1
	ImageIcon img2 = new ImageIcon("gameimg/char1walk2.png");	 //달리기2
	ImageIcon img3 = new ImageIcon("gameimg/char1stand.png");    //서있기
	ImageIcon img4 = new ImageIcon("gameimg/char1jump.png");     //1단
	ImageIcon img5 = new ImageIcon("gameimg/char1fall.png");    //하강
	ImageIcon img6 = new ImageIcon("gameimg/char1jumpjump.png"); //2단
	ImageIcon img7 = new ImageIcon("gameimg/char1lay.png");     //숙이기
	
	
	public PlayGame(String id) {   //캐릭터 번호 추가 9
		super("달려라!! 고대파충류!!");
		this.id = id;
		setBounds(50, 10, 1000, 800);
		setLayout(null);
		//
		
		
		p1 = new JPanel();		
		p1.setBounds(-3000, 0, 8000, 800);
		p1.setLayout(null);
		add(p1);	
				

		character = new JLabel(img1);		
		character.setBackground(new Color(255,255,255));
		character.setOpaque(false);
		character.setBounds(3150, 500, 150, 140);
		character.setOpaque(false);
		p1.add(character);
		

		
		String [] imgs = {                        
				"gameimg/backgroundimg (1).png",
				"gameimg/backgroundimg (2).png",
				"gameimg/backgroundimg (3).png",
				"gameimg/backgroundimg (4).png",
				"gameimg/backgroundimg (5).png",
				"gameimg/backgroundimg (6).png"

		};
		
		ImageIcon img = new ImageIcon(imgs[rd.nextInt(6)]);
		background = new JLabel(img);	
		background.setBounds(3000, 0, 1000, 800);
		p1.add(background);
		
		background2 = new JLabel(img);
		background2.setBounds(4000, 0, 1000, 800);	
		p1.add(background2);
		
		addKeyListener(this);		
		setVisible(true);
		backgoundMove();
		charMove();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void keyPressed(KeyEvent e) {

		int key = e.getKeyCode();
		System.out.println(e.getKeyCode());

		switch(key) {
	         case KeyEvent.VK_UP:	      
	        	 if(character.getY()>=500 && !character.getIcon().equals(img5)) {
	        	 	 character.setSize(130, 180);
	        	 	 character.setIcon(img4);	        		 
	        		 jumpMove();
	        		 
	        	 }else if(character.getY()<500 && !character.getIcon().equals(img5)) {
	        		 character.setSize(130, 180);
	        	 	 character.setIcon(img6);	        		 
	        		 jumpMove2();
	        	 }
	        	 break;
	        	 
	         case KeyEvent.VK_DOWN:
	        	 if(character.getY()>=500 && character.getIcon().equals(img1)) {
		        	 character.setBounds(3150, 520, 150,120);
		        	 character.setIcon(img7);
		        	 break;		        		 
	        	 }else if(character.getY()>=500 && character.getIcon().equals(img2)) {
		        	 character.setBounds(3150, 520, 150,120);
		        	 character.setIcon(img7);
		        	 break;		        		 
	        	 }

			}
		}

	public void keyReleased(KeyEvent e) {	
			if(e.getKeyCode()==(40)&& character.getY()>=500) {
				character.setBounds(3150, 500, 150,140);
				character.setIcon(img1);
				charMove();
			}else {
				fallMove();
			}
		 }
	

	
	void backgoundMove(){		                                //배경이동
		
	    new Thread(new Runnable() {

			public void run() {
				int x = background.getX(), x2 = background2.getX();
				int y = background.getY(), y2 = background2.getY(); 
				int bx = 10;	
				
				while(true) {
	
					try {										
						
						if(background.getX()<=2000) {
							x = 4000;			
							background.setLocation(x, y);
						}
						
						if(background2.getX()<=2000) {
							x2 = 4000;	
							background2.setLocation(x, y);
						}
						
						if(character.getY()>=490) {
							if(character.getIcon().equals(img1) ||character.getIcon().equals(img2)){
							character.setLocation(3150, 500);
						
							}
						}
						
						
						Thread.sleep(100);
						background2.setLocation(x2-=bx, y2);
						background.setLocation(x-=bx, y);
						
						
						
					} catch (Exception e) {
	
						e.printStackTrace();
					}
	
					}
				}
			}).start();
		}
	
	
	void charMove(){			                               //달리기
		
		new Thread(new Runnable() {
			public void run() { //캐릭터 이동 시작	
				
				while(true) {
				   try {	
						Thread.sleep(100);	
						
												
						if(character.getIcon().equals(img1)) {
							character.setIcon(img2);
							
						}else if(character.getIcon().equals(img2)) {
							character.setIcon(img1);			
						}else {
							break;
						}						
										
						
						}catch (Exception e) {
						
							e.printStackTrace();
						}							
					}
				}
		}).start();
	}
	

	
	void jumpMove(){			                             //1단 점프
		
		new Thread(new Runnable() {
			public void run() { //캐릭터 이동 시작	
				int x = character.getX();
				int cy = 10;
				
				
				   try {	
					   while(!character.getIcon().equals(img5)) {

							Thread.sleep(10);					
							
							character.setLocation(x, character.getY()-cy);
		
							if(character.getIcon()!=img4) {
								break;
							}
							
							if(character.getY()<=250) {	
								character.setIcon(img5);
								fallMove();								
								break;								
														
							}
							
						}

					}catch (Exception e) {
					
						e.printStackTrace();
					}										
				}
			}).start();
		}
	
	void jumpMove2(){			                             //2단 점프
		
		new Thread(new Runnable() {
			
			public void run() { //캐릭터 이동 시작	
				int cy = 10;
				
				
				   try {	
					   while(!character.getIcon().equals(img5)) {
							Thread.sleep(10);					
							
							character.setLocation(character.getX(), character.getY()-cy);
		
							if(character.getY()<=80) {
								character.setIcon(img5);
								fallMove();								
								break;						
															
							}						
						}

					}catch (Exception e) {
					
						e.printStackTrace();
					}										
				}
			}).start();
		}
	

	
	void fallMove(){			                              //하강
		
		new Thread(new Runnable() {
			public void run() { //캐릭터 이동 시작	
				int x = character.getX();
				int y = character.getY();
				int cy = 10;
				
				
				   try {	
					   while(true) {
							
							Thread.sleep(10);					
							
							
														
							character.setLocation(x, character.getY()+ cy);
							
							if(character.getIcon()!=img5) {
								break;
							}
			
							if(character.getY()>=500) {
								character.setBounds(3150, 500, 150,140);
								character.setIcon(img1);
								charMove();							
								break;
							}
					   }
					   
					}catch (Exception e) {
					
						e.printStackTrace();
					}											   
				}
			}).start();
		}
	

	public static void main(String[] args) {
		new PlayGame("aaa");

	}
}
