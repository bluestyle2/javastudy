package davinciProj;


public class PlayerInfoMain {

	
	public static void main(String[] args) {
	   
      System.out.println("목록--------------");
      for (PlayerInfoDTO dto : new PlayerInfoDAO().list()) {
         System.out.println(dto);
      }
      
  /*    
      
      System.out.println("상세 : "+new PlayerInfoDAO().detail("aaa"));
      
      
      
      PlayerInfoDTO dto = new PlayerInfoDTO("장희빈", "bbb", "123456", "930511", "01012341234",1,2,0);
      
      
      if(new PlayerInfoDAO().detail(dto.id)==null) {
         System.out.println("추가 : "+new PlayerInfoDAO().insert(dto));
      }else {
         System.out.println("이미 사용중인 ID 입니다.");
      }
      
      System.out.println("변경 : "+new PlayerInfoDAO().modify2(new PlayerInfoDTO("원빈","bbb", "123456","930511","01012341234",60,2,0)));
      
      //System.out.println("변경 : "+new PlayerInfoDAO().modify(new PlayerInfoDTO("bbb", "123456","1993-05-01",1,2,0)));
*/
   }

}


